import React from 'react';

import Form from "../components/Form";


function Cadastro(){
    return(
        <Form title="Faça seu cadastro em nossa plataforma" formName="Cadastro"/>
    );
}

export default Cadastro;