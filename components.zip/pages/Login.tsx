import React from "react";

import Form from "../components/Form"


function Login(){
    return(
        <Form title="Faça seu login em nossa plataforma" formName="Login"/>
    );
}

export default Login;